</body>
<style>
    .devby{
        text-align:right;
        color:#000;
        margin-right:20px;  }
</style>
<p class="devby"> <b>Developed by :- Er. Poonam <b></p>
</html>